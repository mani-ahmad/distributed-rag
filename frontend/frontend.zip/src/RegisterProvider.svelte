<script>
    import { onMount } from 'svelte';
    import { navigate, Link } from 'svelte-routing';
    import NavBar from './NavBar.svelte';
    import JSZip from 'jszip';

    let file;
    let name = '';
    let uploadButtonDisabled = true;
    let fileName = '';
    let fileInput;
    let username = localStorage.getItem('username') || '';

    $: {
        if (username === '') {
            navigate('/signin');
        }
    }

    function onDragOver(event) {
        event.preventDefault();
    }

    function onDrop(event) {
        event.preventDefault();
        if (event.dataTransfer.items && event.dataTransfer.items[0].kind === 'file') {
            file = event.dataTransfer.items[0].getAsFile();
            fileName = file.name;
            uploadButtonDisabled = !file || name === '';
        }
    }

    function onFileChange(event) {
        file = fileInput.files[0];  // Modify this line
        fileName = file.name;
        uploadButtonDisabled = !file || name === '';
    }

    function onNameChange(event) {
        name = event.target.value;
        uploadButtonDisabled = !file || name === '';
    }

    function onUploadContainerClick() {
        document.getElementById('fileInput').click();
    }

    let isLoading = false;
    let modal = { isOpen: false, message: '', isSuccess: true };

    async function upload() {
        isLoading = true;
        const formData = new FormData();
        formData.append('file', file);
        formData.append('name', name);
        formData.append('username', username)

        try {
            const response = await fetch('https://dragapi.zetasolutions.org/register_provider', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                modal = { isOpen: true, message: 'File uploaded successfully', isSuccess: true };
            } else {
                modal = { isOpen: true, message: 'File upload failed', isSuccess: false };
            }
        } catch (error) {
            modal = { isOpen: true, message: 'An error occurred', isSuccess: false };
        } finally {
            isLoading = false;
        }
    }

    function closeModal() {
        modal.isOpen = false;
    }
</script>

<style>
    .upload-container {
        padding: 20px;
        border: 2px dashed #ccc;
        border-radius: 5px;
        text-align: center;
        margin-bottom: 20px;
        cursor: pointer;
        color: black;
    }

    .table-container, .name-field-container {
        margin-top: 20px;
        margin-bottom: 20px; /* Added margin-bottom */
    }

    /* Additional styling can go here */

    .table {
        border-radius: 5px; /* Added rounded corners */
    }

    .white-hover:hover {
		color: black;
		background-color: white;
        border: 1px solid black;
	}

    .white-hover {
        color: white;
        background-color: black;
        border: 1px solid black;
    }

    .invisible {
        display: none;
    }
    .visible {
        display: block;
    }
</style>

<NavBar />
<div class="container mt-3">
    <h1 class="data-heading">
        <span class="title-animate">Register</span>
        <span class="title-animate">Data</span>
        <span class="title-animate">Source</span>
        <span class="title-animate">Provider</span>
    </h1>
    <hr>

    <div class="name-field-container">
        <label for="dataSourceName" class="form-label">Data Provider Name:</label>
        <input type="text" class="form-control" id="dataSourceName" placeholder="Enter name for the data source" bind:value={name} on:input={onNameChange}>
    </div>

    <!-- svelte-ignore a11y-click-events-have-key-events -->
    <div class="upload-container" on:dragover={onDragOver} on:drop={onDrop} on:click={onUploadContainerClick}>
        {#if isLoading}
            <div class="spinner-border text-light" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        {/if}
        <p style="color: #3c3c3c;">Drag your zip file here or click to upload your data provider connector class file</p>
        <label for="fileInput" class={fileName ? 'visible' : 'invisible'}>{fileName}</label>
        <input type="file" id="fileInput" accept=".py" hidden bind:this={fileInput} on:change={onFileChange}>  <!-- Modify this line -->
    </div>

    <button class="btn white-hover mt-2 w-100" disabled={uploadButtonDisabled} on:click={upload}>Register Data Provider</button>

    {#if modal.isOpen}
        <div class="modal show" tabindex="-1" role="dialog" style="display: block; background-color: rgba(0, 0, 0, 0.5);">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">{modal.isSuccess ? 'Success' : 'Failure'}</h5>
                        <button type="button" class="close" aria-label="Close" on:click={closeModal}>
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p>{modal.message}</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" on:click={closeModal}>Close</button>
                    </div>
                </div>
            </div>
        </div>
    {/if}
</div>
