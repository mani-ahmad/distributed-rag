<script>
  import { navigate, Link } from "svelte-routing";
  import NavBar from "./NavBar.svelte";
  import Modal from "./Modal.svelte"; // Import the Modal component
  import { onMount } from "svelte";

  let currentStatus = ""; // Add this variable to control the visibility of the Modal
  let dataSourceName = "";
  let providerSelect = "";
  let accessKey = "";
  let apiKey = "";
  let providers = []; // Add this variable to hold the providers
  let username = localStorage.getItem("username") || "";

    $: {
          if (username === '') {
              navigate('/signin');
          }
      }

  onMount(async () => {
    const response = await fetch("https://dragapi.zetasolutions.org/get_all_providers", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ username }),
    });
    const data = await response.json();
    providers = data.providers;
    console.log(providers);
  });

  async function handleSubmit(event) {
    event.preventDefault();

    currentStatus = "loading";

    const dataSrc = {
      dataSourceName,
      providerSelect,
      accessKey,
      apiKey,
      username,
    };

    console.log(dataSrc);

    const response = await fetch("https://dragapi.zetasolutions.org/add_remote_data_src", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dataSrc),
    });

    const responseData = await response.json();
    console.log(responseData);

    currentStatus = "success";
  }
</script>

<NavBar />

<Modal mode={currentStatus} />

<div class="container mt-5">
  <h3 class="config-header data-heading">
    <span class="title-animate title-word-2">Add Data Source Remotely</span>
  </h3>
  <hr />

  <form on:submit|preventDefault={handleSubmit}>
    <div class="row g-3">
      <div class="col-12">
        <label for="dataSourceName" class="form-label">Data Source Name</label>
        <input
          type="text"
          class="form-control"
          id="dataSourceName"
          placeholder="Enter name for the data source"
          bind:value={dataSourceName}
        />
      </div>

      <div class="col-12">
        <label for="providerSelect" class="form-label">Provider</label>
        <select
          class="form-select"
          id="providerSelect"
          bind:value={providerSelect}
        >
          <option value="">Select Provider</option>
          {#each providers as provider}
            <!-- Use the each block to render the providers -->
            <option value={provider}>{provider}</option>
          {/each}
        </select>
      </div>

      <div class="col-12">
        <div class="card">
          <div class="card-header">Authorization</div>
          <div class="card-body">
            <div class="mb-3">
              <label for="accessKey" class="form-label text-black"
                >Access Key</label
              >
              <input
                type="text"
                class="form-control"
                id="accessKey"
                placeholder="Enter Access Key"
                bind:value={accessKey}
              />
            </div>
            <div class="mb-3">
              <label for="apiKey" class="form-label text-black">API Key</label>
              <input
                type="text"
                class="form-control"
                id="apiKey"
                placeholder="Enter API Key"
                bind:value={apiKey}
              />
            </div>
          </div>
        </div>
      </div>

      <div class="col-12">
        <button type="submit" class="btn btn-outline-light submit-btn w-100">Submit</button>
      </div>
    </div>
  </form>
</div>

<style>
  .submit-btn {
    background-color: #000000;
    color: #ffffff;
    border: 1px solid #323134;
  }

  .submit-btn:hover {
    background-color: #ffffff;
    color: #000000;
    border: 1px solid #000000;
  }
</style>