<script>
	import { navigate, Link } from 'svelte-routing';
    import { handle_promise } from 'svelte/internal';
    import NavBar from './NavBar.svelte';

	let username = '';
    let password = '';
  
	const handleSubmit = async (event) => {
		event.preventDefault();

		const url = 'https://dragapi.zetasolutions.org/signup'; // Replace with your actual endpoint

		const formData = new FormData();
		formData.append('username', username);
		formData.append('password', password);

		try {
			const response = await fetch(url, {
				method: 'POST',
				body: formData,
			});

			if (response.ok) {
				// Handle successful sign up (status 200)
				console.log("Sign up successful");
				alert("Sign up successful, redirecting to data source page")
				navigate("/localdatasource")
				// You can also redirect the user or update the UI accordingly
			} else {
				// Handle errors (status other than 200)
				console.error("Sign up failed");
			}
		} catch (error) {
			console.error("Error during sign up:", error);
		}
	};
	
</script>

<style>
	.white-hover:hover {
		color: black;
		background-color: white;
	}
	
</style>
<div class="patterns">
	<svg width="100%" height="100%">  
	<text x="50%" y="60%"  text-anchor="middle"  >
	DRAG
   </text>
   </svg>
  </div>
<NavBar />

<div class="login-box">
<h2>Create Account</h2>

<form id="sign-up-form" on:submit={handleSubmit}> <div class="user-box">
	<input type="text" name="username" id="username" required="" maxlength="50" bind:value={username}><label for="username">Username</label>
	<span class="error-message"></span> </div>
	<div class="user-box">
	<input type="password" name="password" id="password" required="" minlength="8" bind:value={password}><label for="password">Password</label>
	<span class="error-message"></span> </div>
	<button type="submit" >Sign Up</button>
</form>
</div>
<!-- <script src="validation.js"></script> -->