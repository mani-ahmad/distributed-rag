<script>
	import { navigate, Link } from 'svelte-routing';
    import NavBar from './NavBar.svelte';

	function submitForm(event) {
		event.preventDefault();
		// Get the form element
		const form = document.getElementById('login-form');
		// Submit the form
		form.submit();
  	}

	let username = '';
    let password = '';
    let role = '';
  
	const handleSubmit = async (event) => {
		event.preventDefault();

		const url = 'https://dragapi.zetasolutions.org/login';

		const formData = new FormData();
		formData.append('username', username);
		formData.append('password', password);

		try {
			const response = await fetch(url, {
				method: 'POST',
				body: formData,
			});

			if (response.ok) {
				// Handle successful sign up (status 200)
				console.log("Sign in successful");
				alert("Sign in successful, redirecting to datasource page")
				localStorage.setItem('username', username);
				navigate("/localdatasource")
				// You can also redirect the user or update the UI accordingly
			} else {
				// Handle errors (status other than 200)
				console.error("Sign in failed");
			}
		} catch (error) {
			console.error("Error during sign up:", error);
		}
	};
</script>

<style>
    .white-hover:hover {
        color: rgb(255, 255, 255);
        background-color: rgb(0, 0, 0);
    }

    /* Add this rule to increase the margin-bottom of the labels */
    .user-box label {
        margin-bottom: 20px; /* Adjust this value to your liking */
    }
	.login-btn{
		border-radius: 8px;
		width:80px;
		background-color: rgb(255, 255, 255);
		color:rgb(0, 0, 0);
		
	}
	.login-btn:hover{
		background: #3c3c3c;
		color: #fff;
		border-radius: 8px;
	
	}
</style>

<div class="patterns">
	<svg width="100%" height="100%">  
   <text x="50%" y="60%"  text-anchor="middle"  >
	DRAG
   </text>
   </svg>
  </div>
  <NavBar />

  <div class="login-box">
    <h2>Welcome Back</h2>
    <form id="login-form" on:submit={handleSubmit}>
        <div class="user-box">
            <!-- Move the label above the input field -->
            <input type="text" name="username" required="" maxlength="50" bind:value={username}> <label class='mb-2'>Username</label> 
            <span class="error-message"></span>
        </div>
        <div class="user-box">
             <!-- Move the label above the input field -->
            <input type="password" name="password" required="" minlength="8" bind:value={password}> <label class='mb-2 pb-2'>Password</label>
            <span class="error-message"></span>
        </div>
        <button class ="login-btn"type="submit">
            Log In
        </button>
    </form>
</div>
  <!-- <script src="validation.js"></script> -->