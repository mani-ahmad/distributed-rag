import App from './App.svelte';
import { Router, Route, Link } from 'svelte-routing';

const app = new App({
	target: document.body,
});

export default app;